// export const serverip = 'http://171.111.153.241:8095/' // 需要添加http://
// export const serverip = 'http://192.168.1.12:8087/' // 需要添加http://
// export const serverip = 'http://192.168.1.31:8085/' // 需要添加http://

// export const serverip = 'http://wuhe.gagx.com.cn:9999/' // 需要添加http://
export const serverip = 'http://171.111.153.241:8096/' // 需要添加http://
