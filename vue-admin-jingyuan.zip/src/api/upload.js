import { serverip } from '@/utils/serverIP'
export const ip = serverip + '/base/uploadImage'
export const ip4File = serverip + '/base/uploadFile'
export const ip4Video = serverip + '/base/uploadVideo'
